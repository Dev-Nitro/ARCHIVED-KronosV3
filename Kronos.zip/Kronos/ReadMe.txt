Make sure you extract the .zip folder before running the BootStrapper
Enjoy Kronos